

<?php $__env->startSection('title', 'Edit Art'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Edit Art</h1>
    <hr />
    <form action="<?php echo e(route('arts.update', $arts->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">City</label>
                
                <select name="cityId" id="cityId" class="form-control">
                    <option value="<?php echo e($citi->id); ?>"><?php echo e($citi->name); ?></option>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col mb-3">
                <label class="form-label">Art</label>
                <input type="text" name="name" class="form-control" placeholder="City after" value="<?php echo e($arts->name); ?>" >
            </div>
        </div>
        
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-warning">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/attribute/arts/edit.blade.php ENDPATH**/ ?>