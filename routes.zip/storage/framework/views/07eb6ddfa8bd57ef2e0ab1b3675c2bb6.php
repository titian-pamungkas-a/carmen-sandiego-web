
  
<?php $__env->startSection('title', 'Level Permainan Random'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Detail Level</h1>
    <hr />
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Jumlah Level</label>
            <input type="text" name="levelCount" class="form-control" placeholder="Jumlah Level" value="<?php echo e($levels->levelCount); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Jumlah Kota</label>
            <input type="text" name="cityCount" class="form-control" placeholder="Jumlah Kota" value="<?php echo e($levels->cityCount); ?>" readonly>
        </div>
    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Total Waktu</label>
            <input type="text" name="totalTime" class="form-control" placeholder="Total Waktu" value="<?php echo e($levels->totalTime); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Level Musuh</label>
            <input type="text" name="criminalLevel" class="form-control" placeholder="Level Musuh" value="<?php echo e($levels->criminalLevel); ?>" readonly>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/levels/show.blade.php ENDPATH**/ ?>