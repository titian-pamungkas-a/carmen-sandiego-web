

<?php $__env->startSection('title', 'Attribute setiap Kota'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Edit Attribute Kota</h1>
    <hr />
    <form action="<?php echo e(route('cityattributes.update', $cityattributes->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            
            
            <div class="col">
                <label class="form-label">Kota</label>
                <select name="cityId" id="cityId" class="form-control">
                    
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($city->id != $cityattributes->cityId): ?>
                            <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                        <?php else: ?>
                            <option selected value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col">
                <label class="form-label">Attribute</label>
                <select name="attributeId" id="attributeId" class="form-control">
                    <option value="<?php echo e($attribute->firstWhere('id', $cityattributes->attributeId)->id); ?>"><?php echo e($attribute->firstWhere('id', $cityattributes->attributeId)->name); ?></option>
                    <?php $__currentLoopData = $attribute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($att->id); ?>"><?php echo e($att->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nama Attribute</label>
                <input type="text" name="attributeName" class="form-control" placeholder="Attribute Name" value="<?php echo e($cityattributes->attributeName); ?>" >
            </div>
            
        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-warning">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/cityattributes/edit.blade.php ENDPATH**/ ?>