
  
<?php $__env->startSection('title', 'Level Permainan Random'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Tambah Level</h1>
    <hr />
    <form action="<?php echo e(route('levels.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col">
                <label class="form-label">Jumlah Level</label>
                <input type="text" name="levelCount" class="form-control" placeholder="Jumlah Level">
            </div>
            <div class="col">
                <label class="form-label">Jumlah Kota</label>
                <input type="text" name="cityCount" class="form-control" placeholder="Jumlah Kota">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <label class="form-label">Total Waktu</label>
                <input type="text" name="totalTime" class="form-control" placeholder="Total Waktu">
            </div>
            <div class="col">
                <label class="form-label">Level Musuh</label>
                <input type="text" name="criminalLevel" class="form-control" placeholder="Level Musuh">
            </div>
            
        </div>
 
        <div class="row">
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/levels/create.blade.php ENDPATH**/ ?>