

<?php $__env->startSection('title', 'Hubungan Antar Kota'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Edit Hubungan</h1>
    <hr />
    <form action="<?php echo e(route('links.update', $links->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Kota Sebelum</label>
                <select name="city1" id="city1" class="form-control">
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($links->city1 != $city->id): ?>
                            <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($city->id); ?>" selected><?php echo e($city->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
            </div>
            <div class="col mb-3">
                <label class="form-label">Kota Sesudah</label>
                <select name="city2" id="city2" class="form-control">
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($links->city2 != $city->id): ?>
                            <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($city->id); ?>" selected><?php echo e($city->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Jarak (jam)</label>
                <input type="text" name="distanceHour" class="form-control" placeholder="Distance in Hour" value="<?php echo e($links->distanceHour); ?>" >
            </div>
            
        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-warning">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/links/edit.blade.php ENDPATH**/ ?>