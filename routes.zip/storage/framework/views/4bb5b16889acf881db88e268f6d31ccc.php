
  
<?php $__env->startSection('title', 'Attribute'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Tambah Attribute</h1>
    <hr />
    <form action="<?php echo e(route('attributes.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            
            
            <div class="col">
                <label class="form-label">Nama</label>
                <input type="text" name="name" class="form-control" placeholder="Attribute Name">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <label class="form-label">Kalimat dalam Permainan</label>
                <input type="text" name="sentence" class="form-control" placeholder="Sentence in game">
            </div>
            
        </div>
 
        <div class="row">
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/attributes/create.blade.php ENDPATH**/ ?>