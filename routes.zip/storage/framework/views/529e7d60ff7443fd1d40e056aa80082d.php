
  
<?php $__env->startSection('title', 'Data Penjahat dalam Permainan'); ?>
  
<?php $__env->startSection('contents'); ?>
    <div class="d-flex align-items-center justify-content-between">
        <h1 class="mb-0">List Musuh</h1>
        
    </div>
    
    
    <table class="table table-hover">
        <thead class="table-primary">
            <tr>
                <th>ID</th>
                <th>Nama Musuh</th>
                <th>Hobi</th>
                <th>Rambut</th>
                <th>Pakaian</th>
                <th>Hobi (tempat)</th>
                <th>Hobi (alat)</th>
                <th>Hobi (tokoh)</th>
            </tr>
        </thead>
        <tbody>+
            <?php if($criminals->count() > 0): ?>
                <?php $__currentLoopData = $criminals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th class="align-middle"><?php echo e($rs->id); ?></th>
                        <th class="align-middle"><?php echo e($rs->name); ?></th>
                        <th class="align-middle"><?php echo e($hobbies->firstWhere('id', $rs->religionId)->name); ?></th>
                        <th class="align-middle"><?php echo e($rs->hair); ?></th>
                        <th class="align-middle"><?php echo e($rs->outfit); ?></th>
                        <td class="align-middle"><?php echo e($hobbies->firstWhere('id', $rs->religionId)->place); ?></td>
                        <td class="align-middle"><?php echo e($hobbies->firstWhere('id', $rs->religionId)->equipment); ?></td>
                        <td class="align-middle"><?php echo e($hobbies->firstWhere('id', $rs->religionId)->figure); ?></td>
                        
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="text-center" colspan="5">Product not found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/criminals/index.blade.php ENDPATH**/ ?>