
  
<?php $__env->startSection('title', 'Kota dalam Permainan'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h2 class="mb-0">Detail Kota</h2>
    <hr />
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Nama Kota</label>
            <input type="text" name="name" class="form-control" placeholder="Title" value="<?php echo e($cities->name); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Provinsi</label>
            <input type="text" name="province" class="form-control" placeholder="Price" value="<?php echo e($cities->province); ?>" readonly>
        </div>
    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Gambar</label>
            <input type="text" name="imagePath" class="form-control" placeholder="Product Code" value="<?php echo e($cities->imagePath); ?>" readonly>
        </div>
        
    </div>
    <div>
        <hr style="height:2px;border-width:0;color:gray;background-color:gray" />
    </div>
    <div class="d-flex align-items-center justify-content-between">
        <h2 class="mb-0">Attribute</h2>
        <a href="<?php echo e(route('cityattributes.create')); ?>" class="btn btn-primary">Tambah Attribute</a>
    </div>
    <hr />
    <table class="table table-hover">
        <thead class="table-primary">
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Attribute</th>
                <th>Nama Attribute</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if($attributeName->count() > 0): ?>
                <?php $__currentLoopData = $attributeName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="align-middle"><?php echo e($rs->id); ?></td>
                    <td class="align-middle"><?php echo e($cities->name); ?></td>
                    <td class="align-middle"><?php echo e($attributes->firstWhere('id', $rs->attributeId)->name); ?></td>
                    <td class="align-middle"><?php echo e($rs->attributeName); ?></td>
                    <td class="align-middle">
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <a href="<?php echo e(route('cityattributes.edit', $rs->id)); ?>" type="button" class="btn btn-warning">Edit</a>
                            
                            <form action="<?php echo e(route('cityattributes.destroy', $rs->id)); ?>" method="POST" type="button" class="btn btn-danger p-0" onsubmit="return confirm('Delete?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger m-0">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="text-center" colspan="5">Product not found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <div>
        <hr style="height:2px;border-width:0;color:gray;background-color:gray" />
    </div>
    <div class="d-flex align-items-center justify-content-between">
        <h2 class="mb-0">Hubungan Antar Kota</h2>
        <a href="<?php echo e(route('links.create')); ?>" class="btn btn-primary">Tambah Hubungan</a>
    </div>
    <hr />
    <table class="table table-hover">
        <thead class="table-primary">
            <tr>
                <th>ID</th>
                <th>Kota Sebelum</th>
                <th>Kota Sesudah</th>
                <th>Jarak (jam)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if($links->count() > 0): ?>
                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="align-middle"><?php echo e($rs->id); ?></td>
                    <td class="align-middle"><?php echo e($cities->firstWhere('id', $rs->city1)->name); ?></td>
                    <td class="align-middle"><?php echo e($cities->firstWhere('id', $rs->city2)->name); ?></td>
                    <td class="align-middle"><?php echo e($rs->distanceHour); ?></td>
                    <td class="align-middle">
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <a href="<?php echo e(route('links.edit', $rs->id)); ?>" type="button" class="btn btn-warning">Edit</a>
                            
                            <form action="<?php echo e(route('links.destroy', $rs->id)); ?>" method="POST" type="button" class="btn btn-danger p-0" onsubmit="return confirm('Delete?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger m-0">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="text-center" colspan="5">Product not found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/cities/show.blade.php ENDPATH**/ ?>