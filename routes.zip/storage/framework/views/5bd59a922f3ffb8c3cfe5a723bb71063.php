
  
<?php $__env->startSection('title', 'Hubungan Antar Kota'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Detail Hubungan</h1>
    <hr />
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Kota Sebelum</label>
            <input type="text" name="city1" class="form-control" placeholder="City before" value="<?php echo e($cities->firstWhere('id', $links->city1)->name); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Kota Sesudah</label>
            <input type="text" name="city2" class="form-control" placeholder="City after" value="<?php echo e($cities->firstWhere('id', $links->city2)->name); ?>" readonly>
        </div>
    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">ID</label>
            <input type="text" name="id" class="form-control" placeholder="ID" value="<?php echo e($links->id); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Jarak (jam)</label>
            <input type="text" name="distanceHour" class="form-control" placeholder="Distance in Hour" value="<?php echo e($links->distanceHour); ?>" readonly>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/links/show.blade.php ENDPATH**/ ?>