
  
<?php $__env->startSection('title', 'Hubungan Antar Kota'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Tambah Hubungan</h1>
    <hr />
    <form action="<?php echo e(route('links.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col">
                
                <label class="form-label">Kota Sebelum</label>
                <select name="city1" id="city1" class="form-control">
                    <option value="">== Pilih Kota ==</option>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col">
                
                <label class="form-label">Kota Sesudah</label>
                <select name="city2" id="city2" class="form-control">
                    <option value="">== Pilih Kota ==</option>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <label class="form-label">Jarak (jam)</label>
                <input type="text" name="distanceHour" class="form-control" placeholder="Distance between cities">
            </div>
            
        </div>
 
        <div class="row">
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/links/create.blade.php ENDPATH**/ ?>