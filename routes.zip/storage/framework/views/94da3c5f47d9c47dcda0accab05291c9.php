
  
<?php $__env->startSection('title', 'Fixes Level'); ?>
  
<?php $__env->startSection('contents'); ?>
    <div class="d-flex align-items-center justify-content-between">
        <h1 class="mb-0">List of Fixes Level</h1>
    </div>
    <hr />
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>
    <?php echo e($num = 3); ?>

    <div class="col-1">
        
        <label class="form-label">City before</label>
        <select name="enemyCount" id="enemyCount" class="form-control" onchange="num = this.value">
            <?php for($i = 2; $i <= 6; $i++): ?>
                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
            <?php endfor; ?>
        </select>
    </div>
    <?php for($i = 0; $i < $num; $i++): ?>
        <div class="col">
            <label class="form-label">Distance in Hour</label>
            <input type="text" name="distanceHour" class="form-control" placeholder="Distance between cities">
        </div>
    <?php endfor; ?>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/fix/index.blade.php ENDPATH**/ ?>