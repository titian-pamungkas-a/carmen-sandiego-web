

<?php $__env->startSection('title', 'Level Permainan Random'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Edit Level</h1>
    <hr />
    <form action="<?php echo e(route('levels.update', $levels->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Jumlah Level</label>
                <input type="text" name="levelCount" class="form-control" placeholder="Jumlah Level" value="<?php echo e($levels->levelCount); ?>" >
            </div>
            <div class="col mb-3">
                <label class="form-label">Jumlah Kota</label>
                <input type="text" name="cityCount" class="form-control" placeholder="Jumlah Kota" value="<?php echo e($levels->cityCount); ?>" >
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Total Waktu</label>
                <input type="text" name="totalTime" class="form-control" placeholder="Total Waktu" value="<?php echo e($levels->totalTime); ?>" >
            </div>
            <div class="col mb-3">
                <label class="form-label">Level Musuh</label>
                <input type="text" name="criminalLevel" class="form-control" placeholder="Level musuh" value="<?php echo e($levels->criminalLevel); ?>" >
            </div>
        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-warning">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/levels/edit.blade.php ENDPATH**/ ?>