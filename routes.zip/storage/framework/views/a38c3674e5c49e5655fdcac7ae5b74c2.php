
  
<?php $__env->startSection('title', 'Art'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Detail Art</h1>
    <hr />
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">City</label>
            <input type="text" name="cityId" class="form-control" placeholder="city" value="<?php echo e($city); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Art</label>
            <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo e($arts->name); ?>" readonly>
        </div>
    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">ID</label>
            <input type="text" name="id" class="form-control" placeholder="ID" value="<?php echo e($arts->id); ?>" readonly>
        </div>
        
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/attribute/arts/show.blade.php ENDPATH**/ ?>