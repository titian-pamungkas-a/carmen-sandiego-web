
  
<?php $__env->startSection('title', 'Skenario yang ditentukan'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h2 class="mb-0">Detail Skenario</h2>
    <hr />
    <form action="<?php echo e(route('fixes.update', $fixes->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="col mb-3">
            <label class="form-label">Nama</label>
            <input type="text" name="name" class="form-control" placeholder="Title" value="<?php echo e($fixes->name); ?>">
        </div>
        <div class="row">
            <div class="col mb-3">
                
                <label class="form-label">Penjahat</label>
                    <select name="criminalId" id="criminalId" class="form-control">
                        <?php $__currentLoopData = $criminals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criminal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($criminal->id != $fixes->criminalId): ?>
                                <option value="<?php echo e($criminal->id); ?>"><?php echo e($criminal->name . " - " . $criminal->diff); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($criminal->id); ?>" selected><?php echo e($criminal->name . " - " . $criminal->diff); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
            </div>
            <div class="col mb-3">
                <label class="form-label">Total Waktu</label>
            <input type="text" name="totalTime" class="form-control" placeholder="Total Time" value="<?php echo e($fixes->totalTime); ?>">
            </div>
        </div>
        
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-warning">Update</button>
            </div>
        </div>
    </form>
    
    
    <div>
        <hr style="height:2px;border-width:0;color:gray;background-color:gray" />
    </div>
    <div class="d-flex align-items-center justify-content-between">
        <h2 class="mb-0">Kota</h2>
        <a href="<?php echo e(route('fixes.createcity', $fixes->id)); ?>" class="btn btn-primary">Tambah Kota</a>
    </div>
    <hr />
    <table class="table table-hover">
        <thead class="table-primary">
            <tr>
                <th>ID</th>
                <th>Urutan</th>
                <th>Kota</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if($scenarios->count() > 0): ?>
                <?php $__currentLoopData = $scenarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="align-middle"><?php echo e($rs->id); ?></td>
                    <td class="align-middle"><?php echo e($rs->order); ?></td>
                    <td class="align-middle"><?php echo e($cities->firstWhere('id', $rs->cityId)->name); ?></td>
                    <td class="align-middle">
                        <div class="btn-group" role="group" aria-label="Basic example">
                            
                            <a href="<?php echo e(route('fixes.editcity', ['id'=>$fixes->id, 'cityId'=>$rs->id])); ?>" type="button" class="btn btn-warning">Edit</a>
                            
                            <form action="" method="POST" type="button" class="btn btn-danger p-0" onsubmit="return confirm('Delete?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger m-0">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="text-center" colspan="5">Product not found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/fixes/show.blade.php ENDPATH**/ ?>