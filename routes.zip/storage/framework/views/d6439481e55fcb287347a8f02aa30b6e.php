
  
<?php $__env->startSection('title', 'Attribute setiap Kota'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Detail Attribute Kota</h1>
    <hr />
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Kota</label>
            <input type="text" name="cityId" class="form-control" placeholder="City" value="<?php echo e($cities->firstWhere('id', $cityattributes->cityId)->name); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Attribute</label>
            <input type="text" name="attributeId" class="form-control" placeholder="Attribute" value="<?php echo e($attribute->firstWhere('id', $cityattributes->attributeId)->name); ?>" readonly>
        </div>
    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Nama Attribute</label>
            <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo e($cityattributes->attributeName); ?>" readonly>
        </div>
        
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/cityattributes/show.blade.php ENDPATH**/ ?>