
  
<?php $__env->startSection('title', 'Skenario yang ditentukan'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Tambah Scenario</h1>
    <hr />
    <form action="<?php echo e(route('fixes.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col-6">
                <label class="form-label">Nama</label>
                <input type="text" name="name" class="form-control" placeholder="Nama">
            </div>
            <div class="col-6">
                <label class="form-label">Penjahat</label>
                    <select name="criminalId" id="criminalId" class="form-control">
                        <?php $__currentLoopData = $criminals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criminal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($criminal->id); ?>"><?php echo e($criminal->name . " - " . $criminal->diff); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
            </div>
                
        </div>
        <div class="row mb-3">
            <div class="col">
                <label class="form-label">Total Waktu</label>
                <input type="text" name="totalTime" class="form-control" placeholder="Total Waktu">
            </div>
            
        </div>
 
        <div class="row">
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/fixes/create.blade.php ENDPATH**/ ?>