

<?php $__env->startSection('title', 'Kota dalam Permainan'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Edit Kota</h1>
    <hr />
    <form action="<?php echo e(route('cities.update', $cities->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo e($cities->name); ?>" >
            </div>
            <div class="col mb-3">
                <label class="form-label">Provinsi</label>
                <input type="text" name="province" class="form-control" placeholder="Province" value="<?php echo e($cities->province); ?>" >
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Gambar</label>
                <input type="text" name="imagePath" class="form-control" placeholder="Image Path" value="<?php echo e($cities->imagePath); ?>" >
            </div> 
            
        </div> 
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-warning">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/cities/edit.blade.php ENDPATH**/ ?>