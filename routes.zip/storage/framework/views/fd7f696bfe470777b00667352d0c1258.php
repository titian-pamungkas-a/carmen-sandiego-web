

<?php $__env->startSection('title', 'Attribute'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Edit Attribute</h1>
    <hr />
    <form action="<?php echo e(route('attributes.update', $attributes->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="name" class="form-control" placeholder="name" value="<?php echo e($attributes->name); ?>" >
            </div>
            
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Kalimat dalam Permainan</label>
                <input type="text" name="sentence" class="form-control" placeholder="Sentence" value="<?php echo e($attributes->sentence); ?>" >
            </div>
            
        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-warning">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\asTA\carmenWeb\resources\views/attributes/edit.blade.php ENDPATH**/ ?>